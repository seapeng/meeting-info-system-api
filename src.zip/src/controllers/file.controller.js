class fileController {}

module.exports = new fileController();
