class profileController {}

module.exports = new profileController();
