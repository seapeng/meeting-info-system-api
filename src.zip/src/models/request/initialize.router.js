module.exports = {
  0: {
    model: "findAllGender",
    group: "Enums",
    description: "Get all genders",
  },
  1: {
    model: "findAllRole",
    group: "Enums",
    description: "Get all roles",
  },
  2: {
    model: "findAllTitle",
    group: "Enums",
    description: "Get all titles",
  },
  3: {
    model: "findAllFloor",
    group: "Enums",
    description: "Get all floors",
  },
  4: {
    model: "findAllTitle",
    group: "Enums",
    description: "Get all titles",
  },
  5: {
    model: "findAllStatus",
    group: "Enums",
    description: "Get all Statuses",
  },
};
