module.exports = {
    0: {
      group: "Generate Sample Data",
      description: "Generate sample data",
    },
  };
  