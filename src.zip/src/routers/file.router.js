const express = require("express");

const fileRouter = express.Router();

module.exports = fileRouter;
