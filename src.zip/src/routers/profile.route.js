const express = require("express");

const profileRouter = express.Router();

module.exports = profileRouter;
